---
name: experiment-queue
description: SSH job queue for multi-seed/multi-config ML experiments with OOM-aware retry, stale-screen cleanup, and wave-transition race prevention. Use when user says "batch experiments", "队列实验", "run grid", "multi-seed sweep", "auto-chain experiments", or when 10+ jobs need orchestration on an SSH GPU host.
argument-hint: [manifest-or-grid-spec]
allowed-tools: Bash(*), Read, Grep, Glob, Edit, Write
---

# Experiment Queue

> The queue runs its own scheduler on the remote host (60 s poll, `depends_on`,
> wave transitions). Do not wrap it in a second polling loop: two clocks race
> the wave-transition logic it exists to get right.

Orchestrate large batches of ML experiments on SSH remote GPU servers with proper state tracking, OOM retry, stale cleanup, and wave transitions.

## When to Use This Skill

Use it instead of single `launch-job` runs when you have:

- **≥10 jobs** that need batching across GPUs
- **Multi-seed sweeps** (e.g., 21 seeds × 12 cells)
- **Wave transitions** (run wave 1, wait, run wave 2, wait, run wave 3...)
- **Teacher+student chains** (train teacher then distill; auto-trigger student after teacher done)
- **OOM-prone configs** where you need to retry with different GPU or wait
- **Mixed seed grids** where failed cells need re-running

Do NOT use for:

- A single experiment (use the generated skill's `launch-job` op)
- Modal/Vast.ai deployments (those have their own orchestration)
- Experiments that need manual inspection between runs

## Why This Exists

Based on session audit (2026-04-16), the major wall-clock sinks in multi-seed grid experiments are:

1. **Stale screens** — python finishes, wandb uploads, screen hangs, next wave blocked
2. **OOM on shared GPU** — previous job's memory not yet released
3. **Wave race** — new wave launches before previous wave fully settles
4. **Missing checkpoints** — student launches before teacher saved
5. **Parser duplication** — rewriting multi-seed analysis python every batch

All of these are pure engineering friction that can be orchestrated.

## Core Concepts

### Job Manifest

> **Environment config source:** The manifest's `ssh`, `conda`/`conda_hook`,
> `cwd`, and `resources` fields are populated from the generated experiment
> skill's `ops/env-info.sh` output. Host preparation uses `ops/sync-code.sh` +
> `ops/build-env.sh`:
>
> ```bash
> # --- resolve the project-level experiment skill ---
> PROJECT=$(basename "$(git rev-parse --show-toplevel 2>/dev/null || pwd)" | tr '[:upper:]' '[:lower:]' | sed 's/[^a-z0-9]\+/-/g; s/^-//; s/-$//')
> SKILL_DIR=".claude/skills/run-${PROJECT}-experiment"
> OPS="$SKILL_DIR/scripts/ops"
> [ -d "$OPS" ] || { echo "ERROR: experiment skill not found — run /experiment-env-configuration with the confirmed environment PRD" >&2; exit 1; }
>
> # Read connection and resource details from the op interface
> ENV_INFO=$(sh "$OPS/env-info.sh")
> SSH_ALIAS=$(echo "$ENV_INFO" | jq -r '.connection.ssh_alias')
> CONDA_ENV=$(echo "$ENV_INFO" | jq -r '.connection.conda_env')
> CONDA_HOOK=$(echo "$ENV_INFO" | jq -r '.connection.conda_hook')
> REMOTE_PATH=$(echo "$ENV_INFO" | jq -r '.paths.remote_path')
> RESOURCES_JSON=$(echo "$ENV_INFO" | jq -c '.resources // empty')
>
> # Prepare the host ONCE (sync + build + verify are two ops)
> sh "$OPS/sync-code.sh"
> sh "$OPS/build-env.sh"
> # On failure of either: follow the generated skill's "When an op fails"
> # routing. If the op still fails, abort the queue.
> ```
>
> The generated environment usage skill must be verified and loaded with `reload-skills` before queue work. The SSH execution host needs Node.js 22.12+, the experiment dependencies, `sh`, `jq` and `screen`.
>
> `queue-manager.js` runs on the remote host and
> batch-schedules jobs. The experiment skill's ops run locally and prepare
> the host; they are complementary (single-env control vs batch scheduling).

A manifest lists jobs with explicit state:

```yaml
project: my_grid_experiment
cwd: /home/user/your_project
launch_op: .claude/skills/run-my_grid_experiment/scripts/ops/launch-job.sh
conda: my_env
# Optional: override conda hook path if conda is not at a standard location.
# Can be a bare path (wrapped automatically) or a full `eval "$(... shell.bash hook)"` string.
# Falls back to auto-detect of ~/anaconda3, ~/miniconda3, /opt/anaconda3, etc.,
# or the ARIS_CONDA_HOOK environment variable.
# conda_hook: /custom/path/to/conda
ssh: gpu-server
default_cmd: >
  python run_distill.py --backbone softmax --lam 0.5
  --K 500 --L 96 --W 16 --n_steps 30000 --batch_size 128 --lr 1e-4

preconditions:
  - type: checkpoint_exists
    path: checkpoints/transformer/teacher_L96_K500_N{N}.pt

# Resource scheduling — generic slot model.
# `resources` is required. The scheduler does not read the removed `gpus` form.
resources:
  type: gpu
  ids: [0, 1, 2, 3, 4, 5, 6, 7]
  bind_env: CUDA_VISIBLE_DEVICES
  free_check:
    cmd: "nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits"
    threshold: 500
    unit: MiB
    compare: lt
  exhaustion_patterns:
    - "CUDA out of memory"
    - "torch.OutOfMemoryError"

max_parallel: 8
oom_retry:
  delay: 120
  max_attempts: 3

jobs:
  - id: s200_N64_n50K
    args: { seed: 200, n_hidden: 64, n_train_subset: 50000, subset_seed: 2024 }
  - id: s200_N128_n50K
    args: { seed: 200, n_hidden: 128, n_train_subset: 50000, subset_seed: 2024 }
  # ... 14 more
```

### Job State Machine

```
pending → running → completed
                 ↘ failed_oom → pending (after delay) [retry up to N]
                 ↘ failed_other → stuck (needs manual inspection)
stale_screen_detected → cleaned → pending
```

### Wave Orchestration

A "wave" is a batch of jobs that fit available resource slots. Next wave only starts when:

1. All current-wave python processes have exited
2. No stale screens remain for current-wave tags
3. Resource usage has dropped below the configured threshold (per `resources.free_check`)
4. Precondition checks pass for next-wave jobs

## Workflow

### Step 1: Parse Manifest / Build from Grid

Input can be:

- **YAML manifest** (explicit job list, recommended for complex cases)
- **Grid spec** (Cartesian product of param values, e.g., `N=[64,128,256] × n=[50K,150K,500K,652K]`)
- **Natural language description** (Claude parses into manifest)

Bind the run identifiers once so every later step (manifest save, scp, launch, monitor, resume) refers to the same paths. Set these as local shell variables before generating the manifest:

```bash
# REPLACE the placeholder path before running, or pre-export PROJECT_DIR:
PROJECT_DIR="${PROJECT_DIR:?set PROJECT_DIR to the local project root}"
RUN_TS=$(date -u +%Y%m%dT%H%M%SZ)             # one timestamp per run, reused everywhere
LOCAL_RUN_DIR="$PROJECT_DIR/experiment-queue/$RUN_TS"
mkdir -p "$LOCAL_RUN_DIR"
```

Save the built manifest to `$LOCAL_RUN_DIR/manifest.json` for reproducibility.

### Step 2: Pre-flight

- Check SSH connection works
- Check conda env exists on remote
- Check `cwd` exists on remote
- Check all preconditions (checkpoints, input files)
- Check GPU availability (at least `max_parallel` free GPUs)

If any precondition fails, show user which jobs are blocked and why.

### Step 3: Launch Scheduler

Three preliminaries before launch.

**3a. Find the helpers.** From the project root (see [integration-contract.md](../shared-references/integration-contract.md)):

```bash
QUEUE_TOOLS=".aris/dist/skills/experiment-queue"
[ -f "$QUEUE_TOOLS/queue-manager.js" ] || { echo "ERROR: queue-manager.js not found; rerun the standalone ARL installer to repair it." >&2; exit 1; }
```

**3b. Compute remote paths.** Use both a remote-relative form (for `scp` destinations — modern `scp` runs in SFTP mode and does NOT reliably expand `$HOME` in destination paths) and a `$HOME`-prefixed form (for `ssh ... command` strings, where remote bash WILL expand `$HOME`):

```bash
REMOTE_RUN_REL=".aris_queue/runs/$RUN_TS"          # for scp destinations (relative to remote home)
REMOTE_RUN_DIR="\$HOME/$REMOTE_RUN_REL"            # for ssh command strings (literal $HOME, expanded on remote)
REMOTE_RUN_ABS="$(ssh "$SSH_ALIAS" 'printf "%s" "$HOME"')/$REMOTE_RUN_REL"
```

**3c. Bootstrap the remote run directory and copy the runtime + manifest.** Per-invocation and idempotent. Use a unique run directory rather than `/tmp` so concurrent queues do not collide and so resume-after-crash is reproducible. The helpers import other runtime files and Commander: copying two JavaScript files alone does not work. Transfer `.aris/dist/`, its `package.json` and `node_modules/` together, without project configuration or credentials.

```bash
tar -czf "$LOCAL_RUN_DIR/queue-runtime.tar.gz" -C "$PROJECT_DIR/.aris" dist node_modules package.json
ssh "$SSH_ALIAS" "mkdir -p \"$REMOTE_RUN_DIR/logs\" \"$REMOTE_RUN_DIR/runtime\""
scp "$LOCAL_RUN_DIR/queue-runtime.tar.gz" "$SSH_ALIAS:$REMOTE_RUN_REL/queue-runtime.tar.gz"
ssh "$SSH_ALIAS" "tar -xzf \"$REMOTE_RUN_DIR/queue-runtime.tar.gz\" -C \"$REMOTE_RUN_DIR/runtime\""
scp -r "$SKILL_DIR" "$SSH_ALIAS:$REMOTE_RUN_REL/runtime/environment-skill"
jq --arg op "$REMOTE_RUN_ABS/runtime/environment-skill/scripts/ops/launch-job.sh" \
  '.launch_op = $op' "$LOCAL_RUN_DIR/manifest.json" > "$LOCAL_RUN_DIR/manifest.remote.json"
scp "$LOCAL_RUN_DIR/manifest.remote.json" "$SSH_ALIAS:$REMOTE_RUN_REL/manifest.json"
```

**3d. Launch the scheduler as a detached `nohup` process on the SSH host:**

```bash
ssh "$SSH_ALIAS" "nohup node \"$REMOTE_RUN_DIR/runtime/dist/skills/experiment-queue/queue-manager.js\" \\
  --manifest \"$REMOTE_RUN_DIR/manifest.json\" \\
  --state    \"$REMOTE_RUN_DIR/queue_state.json\" \\
  --log-dir  \"$REMOTE_RUN_DIR/logs\" \\
  > \"$REMOTE_RUN_DIR/queue_mgr.log\" 2>&1 &"
```

Notes for callers:

- `--log-dir` is what `queue-manager.js` actually consumes (per-job log files for OOM detection). Do NOT pass `--log <path>` — that flag is declared but unused, and a single combined log breaks the per-job stale-screen / OOM heuristics.
- Persist `RUN_TS` / `REMOTE_RUN_REL` / `REMOTE_RUN_DIR` to disk so monitoring and resume can reload them without regenerating:

  ```bash
  {
    printf 'PROJECT_DIR=%q\n'    "$PROJECT_DIR"
    printf 'RUN_TS=%q\n'         "$RUN_TS"
    printf 'LOCAL_RUN_DIR=%q\n'  "$LOCAL_RUN_DIR"
    printf 'REMOTE_RUN_REL=%q\n' "$REMOTE_RUN_REL"
    printf 'REMOTE_RUN_DIR=%q\n' "$REMOTE_RUN_DIR"
  } > "$LOCAL_RUN_DIR/run_meta.txt"
  ```

  `%q` shell-escapes the values so the file is safely sourceable later. Note that `REMOTE_RUN_DIR` keeps a literal `$HOME` (do not expand it locally), which is the right form for re-use inside `ssh "..."` strings later.

**3e. Resume an existing queue (only when the user asks).** A fresh `RUN_TS` per invocation is correct for _new_ queues. To resume a crashed queue, do NOT regenerate `RUN_TS` — reload the recorded values and re-run only the launch command (Step 3d), not the bootstrap (Step 3c):

```bash
LOCAL_RUN_DIR="/abs/path/to/project/experiment-queue/<existing-run-ts>"   # the run dir to resume
. "$LOCAL_RUN_DIR/run_meta.txt"                                            # reloads PROJECT_DIR / RUN_TS / REMOTE_RUN_REL / REMOTE_RUN_DIR
# Then re-run Step 3d verbatim. Do NOT re-run Step 3c (would overwrite manifest.json + state.json).
```

The scheduler:

- Reads manifest
- Loops: for each pending job, assign to free GPU, launch via `screen`
  (rendered through the generated skill's `ops/launch-job.sh --print-command`,
  so the queue and single runs share one frozen command template)
- Polls job status (every 60s)
- Detects stale screens (python exited but screen detached → kill)
- Detects OOM (CUDA OOM in log → mark failed_oom → retry after delay)
- Detects completion (expected output JSON/file exists) → mark completed
- Launches next wave when current wave settles
- Writes state to `queue_state.json` continuously (and per-job handles in the
  generated skill's `handles/` format, so `ops/job-status.sh` covers queue jobs)

### Step 4: Monitoring

User can check state anytime, using `$REMOTE_RUN_DIR` from Step 3b (or reload from `$LOCAL_RUN_DIR/run_meta.txt` for a prior run):

```bash
sh "$OPS/job-status.sh" --queue "$REMOTE_RUN_DIR"
# or the raw state:
ssh <server> "cat \"$REMOTE_RUN_DIR/queue_state.json\"" \
  | jq '.jobs | group_by(.status) | map({(.[0].status): length}) | add'
```

### Step 5: Post-completion

When all jobs in `manifest.json` are `completed` or `stuck`:

- The remote scheduler (`queue-manager.js`) exits cleanly with `All jobs done` to its own stdout (captured in `$REMOTE_RUN_DIR/queue_mgr.log`). It does NOT write the local summary.
- The **local** skill agent then aggregates state into `$LOCAL_RUN_DIR/summary.md` (read `$REMOTE_RUN_DIR/queue_state.json`, group by status, optionally pull per-job logs).
- Analysing the results is the caller's job, not this skill's.

## Grid Spec Syntax

Instead of writing 24 job entries manually:

```yaml
grid:
  N: [64, 128, 256]
  n: [50000, 150000, 500000, 652000]
  seed: [42, 200, 201]
template:
  id: "s${seed}_N${N}_n${n}"
  args: {seed: ${seed}, n_hidden: ${N}, n_train_subset: ${n}}
```

Expands to 36 jobs automatically.

## Wave Chaining

For sequential phases (teacher → student):

```yaml
phases:
  - name: train_teachers
    grid:
      N: [384, 512]
    template:
      cmd: python run_train.py --direction c --backbone softmax --n_hidden ${N} ...
      output_check: checkpoints/transformer/teacher_L96_K500_N${N}.pt

  - name: distill_students
    depends_on: train_teachers
    grid:
      N: [384, 512]
      seed: [42, 200, 201]
    template:
      cmd: python run_distill.py --n_hidden ${N} --seed ${seed} ...
      output_check: figures/distill_sw_N${N}_*_seed${seed}.json
```

Scheduler enforces `depends_on`: `distill_students` jobs stay `pending` until all
`train_teachers` jobs are `completed`.

## Resource Exhaustion Handling

The scheduler detects resource exhaustion from stdout using patterns defined
in `resources.exhaustion_patterns` (defaults to CUDA OOM for GPU resources):

```regex
# GPU default:
torch\.OutOfMemoryError: CUDA out of memory
# Custom resources define their own patterns via exhaustion_patterns[]
```

On detection:

1. Mark job `failed_oom`
2. Kill screen
3. Wait `oom_retry.delay` seconds
4. Check if current GPU is free; if not, try another free GPU
5. Requeue as `pending`
6. Max `oom_retry.max_attempts` before marking `stuck`

## Stale Screen Detection

Every 60s, for each running screen:

1. Check screen exists (`screen -ls`)
2. Check python PID still running (`ps -p`)
3. If screen exists but python exited:
   - If expected output file exists → mark `completed`, kill stale screen
   - If no output file → mark `failed_other`, kill screen

## Resume-on-restart

If scheduler crashes / is killed:

1. Read `queue_state.json`
2. For each `running` job: check screen; if still alive, keep; if not, re-evaluate state
3. For each `pending`: continue normally
4. Idempotent: safe to restart scheduler without losing state

## Output: Summary Report

```markdown
# Experiment Queue Summary

**Project**: my_grid_experiment
**Started**: 2026-04-16 11:36:29
**Completed**: 2026-04-16 18:02:14
**Total wall-clock**: 6h 25m
**Jobs**: 40 completed, 2 OOM-retried then completed, 0 stuck

## Phases

| Phase                 | Jobs | Success | OOM retries | Duration |
| --------------------- | ---- | ------- | ----------- | -------- |
| train_teachers        | 2    | 2       | 0           | 58m      |
| distill_students      | 24   | 24      | 2           | 4h 02m   |
| multi_seed_validation | 16   | 16      | 0           | 1h 25m   |

## Results Files

- 42 JSON files in `figures/distill_sw_*.json`

## Key Rules

- **Never overlap jobs on the same resource slot** — always wait for the free_check threshold to clear before launching a new job
- **Always write state to disk** — every state change flushed to `queue_state.json`
- **Idempotent scheduler** — safe to restart; picks up from state file
- **Expected-output-based completion** — don't trust screen state alone; verify output file exists
- **Bounded retry** — max N OOM retries, then mark `stuck` and alert
- **Dependencies enforced at launch** — never launch student before teacher checkpoint exists

## Known Failure Modes

- **SSH connection drop during scheduling**: scheduler keeps running on remote (nohup), just reconnect and check
- **GPU reservation by another user**: scheduler waits, does not pre-empt
- **Disk full on remote**: scheduler detects write failure, marks all pending `stuck`, alerts

## Example Session

User: "跑 T5+T6 全部实验：T5 = N∈{80,192} × n 4 values × seed {200,201}, T6 = N∈{384,512} × n 4 values × seed {42,200,201}; T6 需要先 train teacher"

Claude invokes `/experiment-queue`:

1. Parses description into 2-phase manifest
2. Phase 1: T5 (16 jobs, no teacher dependency) + T6 teacher training (2 jobs)
3. Phase 2: T6 distillation (24 jobs, depends on teachers)
4. Deploys scheduler via nohup
5. Reports: "Scheduler PID 93534, total 42 jobs, estimated 6-7h wall-clock"

Then user can check anytime or wait for summary report.

## Helpers

- `.aris/dist/skills/experiment-queue/queue-manager.js`: the scheduler (`dist/skills/experiment-queue/` inside the ARIS checkout).
- `.aris/dist/skills/experiment-queue/build-manifest.js`: builds a manifest from a grid spec.
